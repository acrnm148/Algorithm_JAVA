package lambda;


public interface MyFuncIF2 {
	int proc1(int n1, int n2);
	int proc2(int n1, int n2);
}
