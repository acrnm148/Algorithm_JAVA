package test;

public class Test {
	public static void main(String[] args) {
		//pair문제
		{
			B a = new C();
			a.hi();
			
			B b = new C();
			b.hi(5);
		}
	}
}
