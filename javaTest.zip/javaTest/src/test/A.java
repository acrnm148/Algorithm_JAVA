package test;

public class A {
	void a() {
		System.out.println("A클래스의  a()메소드 호출됨");
	}
	void hi() {
		System.out.println("A클래스의 hi");
	}
	void hi(int num) {
		System.out.println("A클래스의 hi(int num)");
	}
	
}
