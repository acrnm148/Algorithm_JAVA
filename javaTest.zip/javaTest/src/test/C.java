package test;

//A, B의 자식 -> 전부 다 물려받음
public class C extends B{
	
	
	void a() { //오버라이딩중
		System.out.println("C클래스의  a()메소드 호출");
	}
	
	//@Override => 빨간줄 뜸
	void c() { //얘는 오버라이딩 안함.
		System.out.println("C클래스의  c()메소드 호출");
	}
	
	void hi(int num) {
		System.out.println("c클래스의 hi(int num) 메소드");
	}
	
}
