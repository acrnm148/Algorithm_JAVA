package test;

//A의 자식
public class B extends A{
	void a(int i) {
		System.out.println("B클래스의 a(int i) 메소드 호출됨");
	}
	void b() {
		System.out.println("B클래스의 b() 메소드 호출됨");
	}
}
